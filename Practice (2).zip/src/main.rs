use std::io::{self, Write};

fn main() {
    println!("Internship Application Form");

    let name = read_input("Enter your name: ");
    let email = read_input("Enter your email: ");
    let phone = read_input("Enter your phone number: ");
    let university = read_input("Enter your university: ");
    let major = read_input("Enter your major: ");
    let graduation_year = read_input("Enter your graduation year: ");

    println!("\nThank you for applying!");
    println!("Here is the information you entered:");
    println!("Name: {}", name);
    println!("Email: {}", email);
    println!("Phone: {}", phone);
    println!("University: {}", university);
    println!("Major: {}", major);
    println!("Graduation Year: {}", graduation_year);
}

fn read_input(prompt: &str) -> String {
    let mut input = String::new();
    print!("{}", prompt);
    io::stdout().flush().unwrap();
    io::stdin().read_line(&mut input).expect("Failed to read line");
    input.trim().to_string()
}
